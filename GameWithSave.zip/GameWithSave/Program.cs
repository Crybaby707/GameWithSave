﻿using System;
using System.IO;
using System.Text.Json;

namespace BattleshipGame
{
    [Serializable]
    public class GameState
    {
        public string PlayerBoard { get; set; }
        public string ComputerBoard { get; set; }
        public string PlayerHits { get; set; }
        public string ComputerHits { get; set; }
        public bool IsPlayerTurn { get; set; }
    }

    public class Game
    {
        private const int BoardSize = 10;
        private GameState _state;

        public Game()
        {
            _state = new GameState
            {
                PlayerBoard = InitializeBoard(),
                ComputerBoard = InitializeBoard(),
                PlayerHits = InitializeBoard(),
                ComputerHits = InitializeBoard(),
                IsPlayerTurn = true
            };

            PlaceShips(_state.PlayerBoard);
            PlaceShips(_state.ComputerBoard);
        }

        public Game(GameState state)
        {
            _state = state;
        }

        private string InitializeBoard()
        {
            return new string('.', BoardSize * BoardSize);
        }

        private void PlaceShips(string board)
        {
            Random rand = new Random();
            for (int i = 0; i < 5; i++)
            {
                int index = rand.Next(BoardSize * BoardSize);
                board = board.Substring(0, index) + 'S' + board.Substring(index + 1);
            }
        }

        public void Play()
        {
            while (true)
            {
                PrintBoards();
                if (_state.IsPlayerTurn)
                {
                    PlayerMove();
                }
                else
                {
                    ComputerMove();
                }

                if (CheckWin(_state.PlayerHits))
                {
                    Console.WriteLine("You win!");
                    break;
                }

                if (CheckWin(_state.ComputerHits))
                {
                    Console.WriteLine("Computer wins!");
                    break;
                }

                _state.IsPlayerTurn = !_state.IsPlayerTurn;
            }
        }

        private void PrintBoards()
        {
            Console.WriteLine("Player Hits:");
            PrintBoard(_state.PlayerHits);
            Console.WriteLine("\nComputer Hits:");
            PrintBoard(_state.ComputerHits);
        }

        private void PrintBoard(string board)
        {
            Console.Write("  ");
            for (int i = 0; i < BoardSize; i++)
            {
                Console.Write(i + 1 + " ");
            }
            Console.WriteLine();
            for (int i = 0; i < BoardSize; i++)
            {
                Console.Write((char)('A' + i) + " ");
                for (int j = 0; j < BoardSize; j++)
                {
                    Console.Write(board[i * BoardSize + j] + " ");
                }
                Console.WriteLine();
            }
        }

        private void PlayerMove()
        {
            while (true)
            {
                Console.WriteLine("Enter your move (e.g., A1), or type 'exit' to quit and save the game: ");
                string input = Console.ReadLine();
                if (input.ToLower() == "exit")
                {
                    SaveGameState();
                    Console.WriteLine("Game state saved. Exiting...");
                    Environment.Exit(0);
                }
                if (input.Length < 2 || input.Length > 3 ||
                    input[0] < 'A' || input[0] > 'J' ||
                    !int.TryParse(input.Substring(1), out int y) || y < 1 || y > 10)
                {
                    Console.WriteLine("Invalid input. Please enter a valid move or type 'exit' to quit.");
                    continue;
                }

                int x = input[0] - 'A';
                y--;

                int index = x * BoardSize + y;
                if (_state.PlayerHits[index] != '.')
                {
                    Console.WriteLine("You've already attacked this position. Try again.");
                    continue;
                }

                int shipIndex = x * BoardSize + y;
                if (_state.ComputerBoard[shipIndex] == 'S')
                {
                    Console.WriteLine("Hit!");
                    _state.PlayerHits = _state.PlayerHits.Substring(0, index) + 'X' + _state.PlayerHits.Substring(index + 1);
                }
                else
                {
                    Console.WriteLine("Miss!");
                    _state.PlayerHits = _state.PlayerHits.Substring(0, index) + 'O' + _state.PlayerHits.Substring(index + 1);
                }
                break;
            }
        }

        private void ComputerMove()
        {
            Random rand = new Random();
            while (true)
            {
                int x = rand.Next(BoardSize);
                int y = rand.Next(BoardSize);

                int index = x * BoardSize + y;

                if (_state.ComputerHits[index] == '.')
                {
                    if (_state.PlayerBoard[index] == 'S')
                    {
                        Console.WriteLine("Computer hits!");
                        _state.ComputerHits = _state.ComputerHits.Substring(0, index) + 'X' + _state.ComputerHits.Substring(index + 1);
                    }
                    else
                    {
                        Console.WriteLine("Computer misses!");
                        _state.ComputerHits = _state.ComputerHits.Substring(0, index) + 'O' + _state.ComputerHits.Substring(index + 1);
                    }
                    break;
                }
            }
        }

        private bool CheckWin(string hits)
        {
            int hitCount = 0;
            foreach (char c in hits)
            {
                if (c == 'X')
                {
                    hitCount++;
                }
            }
            return hitCount >= 5;
        }

        public GameState GetGameState()
        {
            return _state;
        }

        public void SaveGameState()
        {
            string json = JsonSerializer.Serialize(_state);
            File.WriteAllText("gamestate.json", json);
        }

        public static GameState LoadGameState()
        {
            if (File.Exists("gamestate.json"))
            {
                string json = File.ReadAllText("gamestate.json");
                return JsonSerializer.Deserialize<GameState>(json);
            }
            return null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Game game;
            GameState state = Game.LoadGameState();

            if (state != null)
            {
                Console.WriteLine("Previous game found. Do you want to continue? (yes/no)");
                string response = Console.ReadLine();
                if (response.ToLower() == "yes")
                {
                    game = new Game(state);
                }
                else
                {
                    game = new Game();
                }
            }
            else
            {
                game = new Game();
            }

            game.Play();

            Console.WriteLine("Do you want to save the current game state? (yes/no)");
            string saveResponse = Console.ReadLine();
            if (saveResponse.ToLower() == "yes")
            {
                game.SaveGameState();
                Console.WriteLine("Game state saved.");
            }
        }
    }
}

